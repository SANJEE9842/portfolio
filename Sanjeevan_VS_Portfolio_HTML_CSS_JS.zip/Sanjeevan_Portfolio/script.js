// Portfolio interactions for Sanjeevan V S
document.addEventListener("DOMContentLoaded", () => {
  const navLinks = [...document.querySelectorAll(".navlinks a")];
  const sections = navLinks
    .map(link => document.querySelector(link.getAttribute("href")))
    .filter(Boolean);

  // Highlight the navigation link for the section currently in view.
  const setActiveLink = () => {
    let currentId = sections[0]?.id;
    for (const section of sections) {
      if (section.getBoundingClientRect().top <= 140) {
        currentId = section.id;
      }
    }
    navLinks.forEach(link => {
      const active = link.getAttribute("href") === `#${currentId}`;
      link.classList.toggle("active", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });
  };

  window.addEventListener("scroll", setActiveLink, { passive: true });
  setActiveLink();

  // Update the copyright year automatically.
  const footer = document.querySelector("footer");
  if (footer) {
    footer.textContent = footer.textContent.replace(/©\\s*\\d{4}/, `© ${new Date().getFullYear()}`);
  }
});
